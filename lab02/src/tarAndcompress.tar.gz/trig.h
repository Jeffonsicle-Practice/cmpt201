#include<stdio.h>
#define n 40.0