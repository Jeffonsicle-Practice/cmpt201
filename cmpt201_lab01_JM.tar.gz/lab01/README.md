#DESCRIPTION
Solutions for lab01
#AUTHOR
Name: Jeffrey Moniz
Email: monizj4@mymacewan.ca
#INSTALLATION
#BUGS
#CONTRIBUTE
#CREDITS
#LICENSE
