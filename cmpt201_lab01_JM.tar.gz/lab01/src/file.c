#include<stdio.h>
//creates the main function with void parameters
int main() 
{
    //prints the string of text
    printf("Welcome to CMPT 201");
    //exits the function
    return 0;
}