#include<stdio.h>
#include<math.h>
#include "math_constants.h"
#include "trig.h"
int main(void)
{
    //initializes the variable and assigns the calculations to the variable q
    float q;
    q = sin(n*PI)+cos(n*PI)+cos((n*PI)/2);

    //prints the calculations
    printf("q: %f\n",q);

    //exits the function
    return 0;
}